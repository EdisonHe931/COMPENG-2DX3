#include <stdint.h>
#include "tm4c1294ncpdt.h"
#include "PLL.h"
#include "SysTick.h"

void PortM_Init(void){
    SYSCTL_RCGCGPIO_R |= SYSCTL_RCGCGPIO_R11;  // activate clock for Port M
    while((SYSCTL_PRGPIO_R & SYSCTL_PRGPIO_R11) == 0){};  // allow time for clock to stabilize
    GPIO_PORTM_DIR_R &= 0x03;  // configure Port M pins (PM0-PM3) as output
    GPIO_PORTM_DEN_R |= 0x03;  // enable digital I/O on Port M pins (PM0-PM3)
    return;
}

void PortN_Init(void){
    SYSCTL_RCGCGPIO_R |= SYSCTL_RCGCGPIO_R12;  // activate clock for Port N
    while((SYSCTL_PRGPIO_R & SYSCTL_PRGPIO_R12) == 0){};  // allow time for clock to stabilize
    GPIO_PORTN_DIR_R |= 0x03;  // make PN1:0 output (PN1:0 built-in LEDs)
    GPIO_PORTN_DEN_R |= 0x03;  // enable digital I/O on PN1:0
    return;
}

void PortF_Init(void){
    SYSCTL_RCGCGPIO_R |= SYSCTL_RCGCGPIO_R5;  // activate clock for Port F
    while((SYSCTL_PRGPIO_R & SYSCTL_PRGPIO_R5) == 0){};  // allow time for clock to stabilize
    GPIO_PORTF_DIR_R |= 0x11;  // configure Port F pins (PF0 PM4) as output
    GPIO_PORTF_DEN_R |= 0x11;  // enable digital I/O on Port F pins (PM0 PM1)
    return;
}

void PortJ_Init(void){
    SYSCTL_RCGCGPIO_R |= SYSCTL_RCGCGPIO_R8;  // activate clock for Port J
    while((SYSCTL_PRGPIO_R & SYSCTL_PRGPIO_R8) == 0){};  // allow time for clock to stabilize
    GPIO_PORTJ_DIR_R &= 0x03;  // configure Port J pins (PJ0-PJ1) as output
    GPIO_PORTJ_DEN_R |= 0x03;  // enable digital I/O on Port J pins (PJ0-PJ1)
    GPIO_PORTJ_PUR_R |= 0x03;  // enable pull-up resistors for Port J
    return;
}

void PortH_Init(void){
    SYSCTL_RCGCGPIO_R |= SYSCTL_RCGCGPIO_R7;  // activate clock for Port H
    while((SYSCTL_PRGPIO_R & SYSCTL_PRGPIO_R7) == 0){};  // allow time for clock to stabilize
    GPIO_PORTH_DIR_R |= 0x0F;  // configure Port H pins (PH0-PH3) as output
    GPIO_PORTH_DEN_R |= 0x0F;  // enable digital I/O on Port H pins (PH0-PH3)
    return;
}

int spin(int direction) {
    uint32_t delay = 1;  // Does your motor spin clockwise or counter-clockwise?
    int32_t position = 0;  
    if(direction == -1) {
        GPIO_PORTH_DATA_R = 0b00001001;
        SysTick_Wait10ms(delay);
        GPIO_PORTH_DATA_R = 0b00001100;
        SysTick_Wait10ms(delay);
        GPIO_PORTH_DATA_R = 0b00000110;
        SysTick_Wait10ms(delay);
        GPIO_PORTH_DATA_R = 0b00000011;
        SysTick_Wait10ms(delay);
        
        return -1;
    }
    if(direction == 1) {
        GPIO_PORTH_DATA_R = 0b00000011;
        SysTick_Wait10ms(delay);
        GPIO_PORTH_DATA_R = 0b00000110;
        SysTick_Wait10ms(delay);
        GPIO_PORTH_DATA_R = 0b00001100;
        SysTick_Wait10ms(delay);
        GPIO_PORTH_DATA_R = 0b00001001;
        SysTick_Wait10ms(delay);
        
    }
    return 1;
}

void returnHome(int position) {
    if(position < 256)
		{
			for(int i = 0; i < position; i++)
			{
				spin(-1);
			}
		}
		if(position > 256)
		{
			for(int i = 0; i < 512-position; i++)
			{
				spin(1);
			}
		}
}

void debounce(uint32_t pin, uint32_t address) {
    while(pin == address) {}
    return;
}



int main(void) {
    PLL_Init();  // Default Set System Clock to 120MHz
    SysTick_Init();  // Initialize SysTick configuration
    PortM_Init();  // Initialize Port M
    PortN_Init();
    PortF_Init();
    PortJ_Init();
    PortH_Init();
    
    uint32_t lastState = 0;
    int currentState = 0;
    uint32_t state = 0;
    uint32_t direction = 1;
    uint32_t step = 16;
    int position = 0;
    uint32_t angle = 0;
    GPIO_PORTN_DATA_R |= 0x01;
    GPIO_PORTF_DATA_R |= 0x10;
    
    while(1) {
        if(GPIO_PORTJ_DATA_R == 0x02 && direction == -1) {
					direction = 1;
					GPIO_PORTN_DATA_R|= 0x01;  
        while(GPIO_PORTJ_DATA_R == 0x02);
				}
				if(GPIO_PORTJ_DATA_R == 0x02 && direction == 1) {
					direction = -1;
					GPIO_PORTN_DATA_R &= ~0x01;  
					while(GPIO_PORTJ_DATA_R == 0x02);
				}
        if(GPIO_PORTJ_DATA_R == 0x01) {
            while(GPIO_PORTJ_DATA_R == 0x01) {}
            GPIO_PORTN_DATA_R |= 0x02;
            state = 1;
        }
        
        while(state == 1) {
            if(GPIO_PORTJ_DATA_R == 0x01) {
                while(GPIO_PORTJ_DATA_R) {}
                GPIO_PORTN_DATA_R |= 0x02;
                state = 0;
                break;
            }
						if(GPIO_PORTJ_DATA_R == 0x02 && direction == -1) {
						direction = 1;
						GPIO_PORTN_DATA_R|= 0x01;  
						while(GPIO_PORTJ_DATA_R == 0x02);
						}
						if(GPIO_PORTJ_DATA_R == 0x02 && direction == 1) {
							direction = -1;
							GPIO_PORTN_DATA_R &= ~0x01;  
							while(GPIO_PORTJ_DATA_R == 0x02);
						}
						 if(GPIO_PORTM_DATA_R == 0x01 && angle == 1) {
            GPIO_PORTF_DATA_R |= 0x10;
            angle = 0;
            step = 16;
            while(GPIO_PORTM_DATA_R == 0x01);
						}
						if(GPIO_PORTM_DATA_R == 0x01 && angle == 0) {
								GPIO_PORTF_DATA_R &= ~0x10;
								angle = 1;
								step = 64;
								while(GPIO_PORTM_DATA_R == 0x01);
						}
            position = (position+spin(direction))%512;
						if(position < 0)
						{
							position = 512;
						}
						if(GPIO_PORTM_DATA_R == 0x02) {
							returnHome(position);
							position = 0;
							state = 0;
						}
						if(position%step == 0)
						{
							GPIO_PORTF_DATA_R |= 0x01;
						}
						if(position%step != 0)
						{
							GPIO_PORTF_DATA_R &= ~0x01;
						}
						
						

        }
        
        GPIO_PORTN_DATA_R &= ~0x02;
        
        if(GPIO_PORTM_DATA_R == 0x01 && angle == 1) {
            GPIO_PORTF_DATA_R |= 0x10;
            angle = 0;
            step = 16;
            while(GPIO_PORTM_DATA_R == 0x01);
        }
        if(GPIO_PORTM_DATA_R == 0x01 && angle == 0) {
            GPIO_PORTF_DATA_R &= ~0x10;
            angle = 1;
            step = 64;
            while(GPIO_PORTM_DATA_R == 0x01);
        }
        if(GPIO_PORTM_DATA_R == 0x02) {
            returnHome(position);
            position = 0;
        }
    }
    return 0;
}
